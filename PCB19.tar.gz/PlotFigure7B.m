% Here we test the dependence of the coefficient \kappa approximating the
% relationship between velocity and g-ratio

close all; clear all;

% compute velocities for g = 0.8 and g = 0.6:
v08 = SpikeTime_LIF_short_g_AC2([0.92 1.95 1.87 2 0.57 2 2],0.8);
v06 = SpikeTime_LIF_short_g_AC2([0.92 1.95 1.87 2 0.57 2 2],0.6);

% compute relative decrease of velocity:
ratv = v08./v06;

% discretidation of internode and node lengths:
Lv = 1e4.*[0.001:0.0001:0.02]; N1 = numel(Lv);
nv = [0.5 1.5 3.5];
ratnL = repmat(Lv, [3 1])./repmat(nv', [1 N1]);

% compute alpha:
alph = log(ratv)./log(log(0.8)/log(0.6));

figure; plot(ratnL',alph'); hold on;

% from AC model:
ratv2 = 1./[1.52 1.30 1.17; 1.88 1.59 1.38; 2.14 1.78 1.53];
ratnL2 = repmat([27 82 154]',[1 3])./repmat([0.5 1.5 3.5],[3 1]);
alph2 = log(ratv2)./log(log(0.8)/log(0.6));

plot(ratnL2,alph2,'o')

% END OF SCRIPT