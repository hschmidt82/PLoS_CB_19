% Plot Figure 6A

close all; clear all;

% parameters:
g = 0.6; % g-ratio
tau = 0.47; % cable time constant ms
tau_node = 0.033;
r = 0.5e0; % axon radius in \mu m
n = 2e0; % node length in \mu m
L = 2e-2*r; % length of myelin segment in cm;
lamb = 19.3e-2*r*sqrt(-log(g)); % sqrt(Rm/Rc); in cm;
lambn = 55e-4*sqrt(r); % cable constant at node in cm
lambn2 = 55*sqrt(r); % cable constant at node in \mu m
RmRn = 394*log(1/g); % Rm / Rn in \mu m^{-1}
I0 = 50e-12;
Icab = I0*2*pi*r*n/(1+pi*r*n*RmRn/(10^4*lamb));
Rlamb = 130e9*log(1/g)/lamb; % factor 1e3 because of [mV]
taum = 0.02;
tauh = 2*taum;
taun = 0.15;
tauk = 2.*taun;
Vth = 15;

% response to exponential current (myelinated and unmyelinated):
ft2Ltla = @(s,L,tau2,lamb) fCabExp(s,L,lamb,tau,tau2);
ft2Ltlan = @(s,L,tau2,lamb) fCabExp(s,L,lamb,tau_node,tau2);

% sodium current (indivisual nodes / different shapes):
maxNa = ((3*tauh/taum)/((3*tauh/taum)+1))^3*(1/(3*tauh/taum+1))^(taum/tauh);
maxNaFH = ((2*tauh/taum)/((2*tauh/taum)+1))^2*(1/(2*tauh/taum+1))^(taum/tauh);
maxNam1 = ((1*tauh/taum)/((1*tauh/taum)+1))^1*(1/(1*tauh/taum+1))^(taum/tauh);
ftNala = @(s,L,lamb) Rlamb*Icab*(1/maxNa).*( ft2Ltla(s,L,tauh,lamb) - 3.*ft2Ltla(s,L,1/(1/taum+1/tauh),lamb) + ...
    3.*ft2Ltla(s,L,1/(2/taum+1/tauh),lamb) -ft2Ltla(s,L,1/(3/taum+1/tauh),lamb) );
ftNala0m1 = @(s,L,lamb) (1/maxNa).*( ft2Ltlan(s,L,tauh,lamb) - ft2Ltlan(s,L,1/(1/taum+1/tauh),lamb) );
ftNalaFH = @(s,L,lamb) Rlamb*Icab*(1/maxNaFH).*( ft2Ltla(s,L,tauh,lamb) - 2.*ft2Ltla(s,L,1/(1/taum+1/tauh),lamb) + ...
    ft2Ltla(s,L,1/(2/taum+1/tauh),lamb) );
ftNalam1 = @(s,L,lamb) Rlamb*Icab*(1/maxNam1).*( ft2Ltla(s,L,tauh,lamb) - 1.*ft2Ltla(s,L,1/(1/taum+1/tauh),lamb) );

% sum over nodes:
% myelinated:
ftotNaN2 = @(s,L,l,N) ((I0/Icab)*2*pi*r*l/(1+pi*r*l*RmRn/(10^4*lamb))).*( ...
            sum(ftNala(s(:)*[1:N],repmat(L+l*lamb/lambn2,[numel(s) 1])*[1:N],lamb).*exp(-0.*repmat(l,[numel(s) 1])*[1:N]./lambn2),2) );
ftotNaFHN2 = @(s,L,l,N) ((I0/Icab)*2*pi*r*l/(1+pi*r*l*RmRn/(10^4*lamb))).*( ...
            sum(ftNalaFH(s(:)*[1:N],repmat(L+l*lamb/lambn2,[numel(s) 1])*[1:N],lamb).*exp(-0.*repmat(l,[numel(s) 1])*[1:N]./lambn2),2) );
ftotNam1N2 = @(s,L,l,N) ((I0/Icab)*2*pi*r*l/(1+pi*r*l*RmRn/(10^4*lamb))).*( ...
            sum(ftNalam1(s(:)*[1:N],repmat(L+l*lamb/lambn2,[numel(s) 1])*[1:N],lamb).*exp(-0.*repmat(l,[numel(s) 1])*[1:N]./lambn2),2) );
% unmyelinated:
ftotNaFHNm1 = @(s,L,N) 0.5.*I0*3.3*1e12.*( ...
            sum(ftNala0m1(s(:)*[1:N],repmat(L,[numel(s) 1])*[1:N],lambn),2) );

% parameter screening:
N1 = 72;
N2 = 60;
Vthr = 15;
v_un_1 = 1e-3/flogsolve(@(t) ftotNaFHNm1(t,1e-4,1e3)-Vthr); 
Nnb = 1e3;
Nmax = 3; Lmax = 1.8;
for p = 1:N1
    for m = 1:N2
        if p>1
            tin = ttold(m);
            tinFH = ttFHold(m);
        else
            tin = 0.005;
            tinFH = 0.003;
        end
        tt = fsolve(@(t) ftotNaN2(t,L*(0.1+(Lmax/N1)*(p-1)),m*(Nmax/N2),Nnb)-Vthr,tin,...
            optimoptions('fsolve','Display','off','FunctionTolerance',1e-8,'StepTolerance',1e-8)); 
        ttFH = fsolve(@(t) ftotNaFHN2(t,L*(0.1+(Lmax/N1)*(p-1)),m*(Nmax/N2),Nnb)-Vthr,tinFH,...
            optimoptions('fsolve','Display','off','FunctionTolerance',1e-8,'StepTolerance',1e-8)); 
        ttm1 = fsolve(@(t) ftotNam1N2(t,L*(0.1+(Lmax/N1)*(p-1)),m*(Nmax/N2),Nnb)-Vthr,tinFH,...
            optimoptions('fsolve','Display','off','FunctionTolerance',1e-8,'StepTolerance',1e-8)); 
        crm1(m,p) = (10*L*(0.1+(Lmax/N1)*(p-1))+m*(Nmax/N2)*1e-3)/ttm1; 
        crm1_corr(m,p) = (1e4*L*(0.1+(Lmax/N1)*(p-1))+m*(Nmax/N2))*crm1(m,p)*v_un_1/...
            (m*(Nmax/N2)*crm1(m,p) + 1e4*L*(0.1+(Lmax/N1)*(p-1))*v_un_1);
        ttold(m) = tt; ttFHold(m) = ttFH;
    end
    disp([p N1]); 
end

figure; imagesc(crm1_corr'); clim([2.5 8]); colorbar; axis xy; hold on; 
contour(crm1_corr',max(crm1_corr(:)).*[0.95 0.9 0.8 0.7],'k'); axis xy

% END OF FILE