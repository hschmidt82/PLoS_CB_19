% Plot Figure 9.

close all; clear all;

% parameters:
g = 0.6; % g-ratio
tau = 0.47; % cable time constant ms
r = 0.5;
n = 1e0; % node length in \mu m
L = 2e-2*r; % length of myelin segment in cm;
lamb = 19.3e-2*r*sqrt(-log(g)); % sqrt(Rm/Rc); in cm;
lambn = 55e-4*sqrt(r);
RmRn = 394*log(1/g); % Rm / Rn in \mu m^{-1}
I0 = 50e-12;
Icab = I0*2*pi*r*n/(1+pi*r*n*RmRn/(10^4*lamb));
Rlamb = 130e9*log(1/g)/lamb;
taum = 0.02;
tauh = 2.*taum;
taun = 0.15;
tauk = 2.*taun;
Vth = 25;
gamm = 0.5;
lamb1 = lamb*sqrt(1-gamm);
lamb2 = lamb*sqrt(1+gamm);
delta_t = 0.02;

dt = 1e-3;
t = [0:dt:1e0];

% exponential current:
ft2Lt = @(s,L,tau2,lamb) fCabExp(s,L,lamb,tau,tau2);

% sodium current:
maxNam1 = ((1*tauh/taum)/((1*tauh/taum)+1))^1*(1/(1*tauh/taum+1))^(taum/tauh);
ftNas = @(s,L,lam) (lamb/lam)*Rlamb*Icab*(1/maxNam1).*( ft2Lt(s,L,tauh,lam) - ft2Lt(s,L,1/(1/taum+1/tauh),lam) );

% potassium current:
maxK = ((4*tauk/taun)/((4*tauk/taun)+1))^4*(1/(4*tauk/taun+1))^(taun/tauk);
ftKs = @(s,L,lam) (lamb/lam)*Rlamb*Icab*(1/maxK).*( ft2Lt(s,L,tauk,lam) - 4.*ft2Lt(s,L,1/(1/taun+1/tauk),lam) + ...
    6.*ft2Lt(s,L,1/(2/taun+1/tauk),lam) -4.*ft2Lt(s,L,1/(3/taun+1/tauk),lam) +ft2Lt(s,L,1/(4/taun+1/tauk),lam) );

t2 = [-1:0.01:3];
ftot = zeros(numel(t),20); ftot1 = ftot; ftot2 = ftot; ftot3 = ftot; ftot4 = ftot;
ftotK = ftot; ftotp = ftot; ftotpK = ftot;
for m = 1:40
    ff1b = ftNas(m.*t,m.*L,lamb1) + ftNas(m.*t-delta_t,m.*L,lamb1);
    ff2b = ftNas(m.*t,m.*L,lamb2) - ftNas(m.*t-delta_t,m.*L,lamb2);
    ff1 = (ff1b+ff2b)./2;
    ff2 = (ff1b-ff2b)./2;
    ftot1(:,m) = ff1;
    ftot2(:,m) = ff2;
    ff1b = ftNas(m.*t,m.*L,lamb1) + ftNas(m.*t,m.*L,lamb1);
    ff2b = ftNas(m.*t,m.*L,lamb2) - ftNas(m.*t,m.*L,lamb2);
    ff1 = (ff1b+ff2b)./2;
    ff2 = (ff1b-ff2b)./2;
    ftot1b(:,m) = ff1;
    ftot2b(:,m) = ff2;
    ff1b = ftNas(m.*t,m.*L,lamb1);
    ff2b = ftNas(m.*t,m.*L,lamb2);
    ff1 = (ff1b+ff2b)./2;
    ff2 = (ff1b-ff2b)./2;
    ftot3(:,m) = ff1;
    ftot4(:,m) = ff2;
end

for m=-40:40
    ff1c = ftNas(m.*0.02+t2,abs(m).*L,lamb1)-(45/1200).*ftKs(m.*0.02+t2,abs(m).*L,lamb1);
    ff2c = ftNas(m.*0.02+t2,abs(m).*L,lamb2)-(45/1200).*ftKs(m.*0.02+t2,abs(m).*L,lamb2);
    ff3 = (ff1c+ff2c)./2;
    ff4 = (ff1c-ff2c)./2;
    ftot6(:,41+m) = ff3;
    ftot7(:,41+m) = ff4;
end

figure; plot(sum(ftot1,2)); hold on; plot(sum(ftot2,2)); xlim([0 200])
figure; plot(sum(ftot1b,2)); hold on; plot(sum(ftot3,2)); xlim([0 200])
figure; plot(sum(ftot6,2)); hold on; plot(sum(ftot7,2));


% END OF FILE