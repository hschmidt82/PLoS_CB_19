% Here we plot parameter dependencies of v as function of r and g.

close all; clear all;

r = [1:100].*0.05;

tic; for o = 1:numel(r); [vv3(o),vv4(o)] = SpikeTime_LIF_short_rg(r(o).*0.6,0.6); end; toc
figure; plot(2.*r,vv3); xlim([0 5]); hold on;
% 
tic; for o = 1:numel(r); [vv3(o),vv4(o)] = SpikeTime_LIF_short_delta_rg(r(o).*0.6,0.6,0); end; toc
plot(2.*r,vv3); xlim([0 5])
% 
tic; for o = 1:numel(r); [vv3(o),vv4(o)] = SpikeTime_LIF_short_delta_rg(r(o).*0.6,0.6,0.03); end; toc
plot(2.*r,vv3); xlim([0 5])

tic; for o = 1:numel(r); [vv3(o),vv4(o)] = SpikeTime_LIF_short_exp_rg(r(o).*0.6); end; toc
plot(2.*r,vv3); xlim([0 5])

tic; for o = 1:numel(r); [vv3(o),vv4(o)] = SpikeTime_LIF_short_AC_rgL(r(o).*0.81,0.81); end; toc
plot(2.*r,vv3); xlim([0 5])
plot([1,2,3]./0.81,[4,7.65,11.28],'o'); xlim([0 5])

plot(2.*r,3.6.*2.*r,'k'); xlim([0 5])
plot(2.*r,4.6.*2.*r,'k'); xlim([0 5])

ylim([0 20])

% END OF FILE