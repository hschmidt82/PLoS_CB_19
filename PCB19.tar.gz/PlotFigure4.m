% Plot Figure 4.

close all; clear all;

% parameters:

g = 0.6; % g-ratio
tau = 0.47; % cable time constant ms
tau_node = 0.033;
r = 0.5e0; % axon radius in \mu m
n = 2e0; % node length in \mu m
L = 2e-2*r; % length of myelin segment in cm;
lamb = 19.3e-2*r*sqrt(-log(g)); % sqrt(Rm/Rc); in cm;
lambn = 55e-4*sqrt(r); % cable constant at node in cm
lambn2 = 55*sqrt(r); % cable constant at node in \mu m
RmRn = 394*log(1/g); % Rm / Rn in \mu m^{-1}
I0 = 50e-12;
Icab = I0*2*pi*r*n/(1+pi*r*n*RmRn/(10^4*lamb));
Rlamb = 130e9*log(1/g)/lamb; % factor 1e3 because of [mV]
taum = 0.02;
tauh = 2*taum;
taun = 0.15;
tauk = 2.*taun;
Vth = 15;

% response to exponential current:
ft2Lt = @(s,L,tau2) fCabExp(s,L,lamb,tau,tau2);

% sodium current:

maxNa = ((3*tauh/taum)/((3*tauh/taum)+1))^3*(1/(3*tauh/taum+1))^(taum/tauh);
ftNa = @(s,L) Rlamb*Icab*(1/maxNa).*( ft2Lt(s,L,tauh) - 3.*ft2Lt(s,L,1/(1/taum+1/tauh)) + ...
    3.*ft2Lt(s,L,1/(2/taum+1/tauh)) -ft2Lt(s,L,1/(3/taum+1/tauh)) );

% potassium current:

maxK = ((4*tauk/taun)/((4*tauk/taun)+1))^4*(1/(4*tauk/taun+1))^(taun/tauk);
ftK = @(s,L) Rlamb*Icab*(1/maxK).*( ft2Lt(s,L,tauk) - 4.*ft2Lt(s,L,1/(1/taun+1/tauk)) + ...
    6.*ft2Lt(s,L,1/(2/taun+1/tauk)) -4.*ft2Lt(s,L,1/(3/taun+1/tauk)) +ft2Lt(s,L,1/(4/taun+1/tauk)) );



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% plot representative AP
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% test color palette:
fff = 4/4;
dt = 2e-3;
t = [0:dt:2e0];
figure; hold on;
for m = 1:17
    if (m<=3)
        mycol = ([0.5 0.1 0.8].*(4-m)^(fff)+[1 1 1].*(4^(fff)-(4-m)^(fff)))./4^(fff);
        fill([t t(end:-1:1)],[(m-1).*ones(size(t)) m.*ones(size(t))],mycol,'EdgeColor',1.5.*[0.5 0.5 0.5]);
    end
    if (m<9)&&(m>3)
        mycol = ([0 0.3 0.7].*(9-m)^(fff)+[1 1 1].*(6^(fff)-(9-m)^(fff)))./6^(fff);
        fill([t t(end:-1:1)],[(m-1).*ones(size(t)) m.*ones(size(t))],mycol,'EdgeColor',1.5.*[0.5 0.5 0.5]);
    end
    if m==9
        mycol = ([0.85 0.925 0.85]);
        fill([t t(end:-1:1)],[(m-1).*ones(size(t)) m.*ones(size(t))],mycol,'EdgeColor',1.5.*[0.5 0.5 0.5]);
    end
    if (m>9)&&(m<15)
        mycol = ([0.9 0.5 0.1].*(m-9)^(fff)+[1 1 1].*((6)^(fff)-(m-9)^(fff)))./6^(fff);
        fill([t t(end:-1:1)],[(m-1).*ones(size(t)) m.*ones(size(t))],mycol,'EdgeColor',1.5.*[0.5 0.5 0.5]);
    end
    if m>=15
        mycol = ([0.7 0.0 0.1].*(m-14)^(fff)+[1 1 1].*((4)^(fff)-(m-14)^(fff)))./4^(fff);
        fill([t t(end:-1:1)],[(m-1).*ones(size(t)) m.*ones(size(t))],mycol,'EdgeColor',1.5.*[0.5 0.5 0.5]);
    end
    mycol2(m,:) = mycol;
end
ylim([0 17])

% compute delay between adjacent nodes:
tsp = fsolve(@(ts) sum(ftNa([1:40].*ts,[1:40].*(L+1e-4*n*lamb/lambn))-(45/1200).*ftK([1:40].*ts,[1:40].*(L+1e-4*n*lamb/lambn)))-15,0.02);

% compute response profiles (individual currents):
t = [-1:1e-2:4];
for m = 1:81
    ftotppp(:,m) = ftNa(t+(m-41)*tsp,abs(m-41)*(L+1e-4*n*lamb/lambn))';
    ftotpppK(:,m) = ftK(t+(m-41)*tsp,abs(m-41)*(L+1e-4*n*lamb/lambn))';
end

% Figure 4A:
ftotpppFHc = cumsum(ftotppp(:,end:-1:1),2);

ftotpppFHc2(:,1) = ftotpppFHc(:,1);
ftotpppFHc2(:,2) = ftotpppFHc(:,20);
ftotpppFHc2(:,3) = ftotpppFHc(:,30);
ftotpppFHc2(:,4) = ftotpppFHc(:,35);
ftotpppFHc2(:,5:15) = ftotpppFHc(:,36:46);
ftotpppFHc2(:,16) = ftotpppFHc(:,51);
ftotpppFHc2(:,17) = ftotpppFHc(:,61);
ftotpppFHc2(:,18) = ftotpppFHc(:,81);
figure; hold on;
for m = 1:17
    fill([t t(end:-1:1)],[ftotpppFHc2(:,m)' ftotpppFHc2(end:-1:1,m+1)'],mycol2(m,:),'EdgeColor',mycol);
    plot(t,ftotpppFHc2(:,m),'Color',1.5.*[0.5 0.5 0.5]);
end
plot(t,ftotpppFHc2(:,end),'k');

% Figure 4D:
figure; bar([-20:0],ftotpppFHc(101,21:41)-ftotpppFHc(101,20:40))

% Figure 4B:
ftotpppFHc = -(90/1200).*cumsum(ftotpppK(:,end:-1:1),2);

ftotpppFHc2(:,1) = ftotpppFHc(:,1);
ftotpppFHc2(:,2) = ftotpppFHc(:,20);
ftotpppFHc2(:,3) = ftotpppFHc(:,30);
ftotpppFHc2(:,4) = ftotpppFHc(:,35);
ftotpppFHc2(:,5:15) = ftotpppFHc(:,36:46);
ftotpppFHc2(:,16) = ftotpppFHc(:,51);
ftotpppFHc2(:,17) = ftotpppFHc(:,61);
ftotpppFHc2(:,18) = ftotpppFHc(:,81);

figure; hold on;
for m = 1:17
    fill([t t(end:-1:1)],[ftotpppFHc2(:,m)' ftotpppFHc2(end:-1:1,m+1)'],mycol2(m,:),'EdgeColor',mycol);
    plot(t,ftotpppFHc2(:,m),'Color',1.5.*[0.5 0.5 0.5]);
end
plot(t,ftotpppFHc2(:,end),'k');

% Figure 4C:
ftotpppFHc = cumsum(ftotppp(:,end:-1:1) - (45/1200).*ftotpppK(:,end:-1:1),2);

ftotpppFHc2(:,1) = ftotpppFHc(:,1);
ftotpppFHc2(:,2) = ftotpppFHc(:,20);
ftotpppFHc2(:,3) = ftotpppFHc(:,30);
ftotpppFHc2(:,4) = ftotpppFHc(:,35);
ftotpppFHc2(:,5:15) = ftotpppFHc(:,36:46);
ftotpppFHc2(:,16) = ftotpppFHc(:,51);
ftotpppFHc2(:,17) = ftotpppFHc(:,61);
ftotpppFHc2(:,18) = ftotpppFHc(:,81);

figure; hold on;
for m = 1:17
    fill([t t(end:-1:1)],[ftotpppFHc2(:,m)' ftotpppFHc2(end:-1:1,m+1)'],mycol2(m,:),'EdgeColor',mycol);
    plot(t,ftotpppFHc2(:,m),'Color',1.5.*[0.5 0.5 0.5]);
end
plot(t,ftotpppFHc2(:,end),'k');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% END OF FILE