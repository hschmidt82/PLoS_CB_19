% Here we plot parameter dependencies of v as function of r and g.

close all; clear all;

r = [1:100].*0.05;
g = [0.5:0.01:0.9];

tic; for o = 1:numel(r); for p = 1:numel(g); [vv5(o,p),vv6(o,p)] = SpikeTime_LIF_short_rg(r(o).*g(p),g(p)); end; end; toc
% figure; mesh(vv5); drawnow;
% figure; mesh(vv6); drawnow;

figure; imagesc(vv5(:,1:31)); axis xy; hold on; contour(vv5(:,1:31),'k');

tic; for o = 1:numel(r); for p = 1:numel(g); [vv7(o,p),vv8(o,p)] = SpikeTime_LIF_short_rg(r(o),g(p)); end; end; toc
% figure; mesh(vv7)
% figure; mesh(vv8)

figure; imagesc(vv7(:,1:31)); axis xy; hold on; contour(vv7(:,1:31),'k');

% END OF FILE