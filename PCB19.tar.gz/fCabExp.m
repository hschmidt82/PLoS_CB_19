function [out] = fCabExp(s,L,lamb,tau,tau2)
% This function is the solution to the cable equation with exponential
% input current.
% The function is calculated based on the approximation of the complex
% error function found in Abramowitz and Stegun, Eq. 7.1.29 (p.299)

if L==0; L=1e-8; end;

x = real((L.*sqrt(tau)./(2*lamb.*sqrt(s))));
y = real(sqrt(s.*(1/tau2-1/tau)).*(tau>tau2) + sqrt(s.*(1/tau-1/tau2)).*(tau<tau2));

out = sin(2.*x.*y).*(erf(x)-1+exp(-x.^2)./(2*pi.*x));

RelErr = 1; n = 1;
while RelErr>1e-8
% while RelErr>1e-20
    nout = (2/pi).*exp(-x.^2).*(exp(-n.^2./4)./(n^2+4.*x.^2)).*...
        ( 2.*x.*sin(2.*x.*y) + n.*sinh(n.*y) );
    out = out + nout;
    n = n+1;
    RelErr = max(abs(nout./out));
end

out = (1/tau).*exp(-s./tau2).*(sqrt(tau/((1/tau2-1/tau).*(tau>tau2)+(1/tau-1/tau2).*(tau<tau2)))./2).*out.*(s>0);

ind = find(isnan(out));
if numel(ind)>0; out(ind) = 0; end;
ind = find(isinf(out));
if numel(ind)>0; out(ind) = 0; end;

end

% END OF FUNCTION