% Here we plot parameter dependencies of v as function of r and g.

close all; clear all;

r = [1:1:51].*0.05;

tic; for o = 1:numel(r); [vv(o)] = SpikeTime_LIF_short_r_unmyel2(r(o),1); end; toc
figure; plot(2.*r,vv); xlim([0 5]); hold on; 

tic; for o = 1:numel(r); [vv(o)] = SpikeTime_LIF_short_r_unmyel2(r(o),0.1); end; toc
plot(2.*r,vv); xlim([0 5]);

tic; for o = 1:numel(r); [vv(o)] = SpikeTime_LIF_short_r_unmyel2(r(o),0.02); end; toc
plot(2.*r,vv); xlim([0 5]);

% END OF FILE