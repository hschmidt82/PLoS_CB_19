function [crm1_corr,ttm1] = fSpikeTime_fit(par,g,dummy)

if nargin<3
    dummy = [];
end

if nargin<2
    g = 0.81;
end

% parameters:
tau = 1.45;
r = 0.365;
n = 1e0; % node length in \mu m
L = 2e-2*r; % length of myelin segment in cm;
lamb = 24e-2*r*sqrt(-log(g)); % in cm;
lambn = 68*1e-4*sqrt(r); % cable constant at node in cm
lambn2 = 68*sqrt(r); % cable constant at node in \mu m
RmRn = 394*log(1/g); % Rm / Rn in \mu m^{-1} %% <<----
I0 = 200e-12;
Icab = I0*2*pi*r*n/(1+pi*r*n*RmRn/(10^4*lamb));
Rlamb = 130e9*log(1/g)/lamb; % factor 1e3 because of [mV]
taum = 0.07;
tauh = 0.16;
taun = 0.15;
tauk = 2.*taun;
taunode = 0.02;
Vthr = 4;

% exponential current:
ft2Ltla = @(s,L,tau2,lamb) fCabExp(s,L,lamb,tau,tau2);
ft2Ltlanode = @(s,L,tau2,lamb) fCabExp(s,L,lamb,taunode,tau2);

% sodium current:

maxNa = ((3*tauh/taum)/((3*tauh/taum)+1))^3*(1/(3*tauh/taum+1))^(taum/tauh);
maxNam1 = ((1*tauh/taum)/((1*tauh/taum)+1))^1*(1/(1*tauh/taum+1))^(taum/tauh);

ftNala0m1 = @(s,L,lamb) (1/maxNa).*( ft2Ltlanode(s,L,tauh,lamb) - ft2Ltlanode(s,L,1/(1/taum+1/tauh),lamb) );
ftNalam1 = @(s,L,lamb) Rlamb*Icab*(1/maxNam1).*( ft2Ltla(s,L,tauh,lamb) - 1.*ft2Ltla(s,L,1/(1/taum+1/tauh),lamb) );
        
ftotNam1N2 = @(s,L,l,N) ((I0/Icab)*2*pi*r*l/(1+pi*r*l*RmRn/(10^4*lamb))).*( ...
            sum(ftNalam1(s(:)*[1:N],repmat(L+l*lamb/lambn2,[numel(s) 1])*[1:N],lamb).*exp(-0.*repmat(l,[numel(s) 1])*[1:N]./lambn2),2) );
        
% mimicking unmyelinated axon:  
ftotNaFHNm1 = @(s,L,N) 0.5.*I0*3.3*1e12.*( ...
            sum(ftNala0m1(s(:)*[1:N],repmat(L,[numel(s) 1])*[1:N],lambn),2) );

% check dependence of L and n on v:
N2 = 3;
Lv = [0.001:0.0001:0.02]; N1 = numel(Lv);
nv = [0.5 1.5 3.5];
v_un = 1e-3/flogsolve(@(t) ftotNaFHNm1(t,1e-4,1e3)-Vthr); 
Nnb = 1e3;
for p = 1:N1
    for m = 1:N2
        if p>1
            tinFH = ttFHold(m);
        else
            tinFH = 0.005;
        end
        ttm1(m,p) = flogsolve(@(t) ftotNam1N2(t,Lv(p),nv(m),Nnb)-Vthr); 
        crm1(m,p) = (10*Lv(p)+nv(m)*1e-3)/ttm1(m,p); 
        crm1_corr(m,p) = (1e4*Lv(p)+nv(m))*crm1(m,p)*v_un/...
            (nv(m)*crm1(m,p) + 1e4*Lv(p)*v_un);
        ttFHold(m) = ttm1(m,p);
    end
end

end

% END OF FILE