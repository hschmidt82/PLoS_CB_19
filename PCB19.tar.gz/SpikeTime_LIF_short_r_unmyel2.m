function [crm1] = fSpikeTime_fit(r,rho,dummy)

if nargin<3
    dummy = [];
end

if nargin<2
    rho = 1;
end

if nargin<1
    r = 0.5;
end

% fixed parameters:
I0s = 50;
taum = 0.02;
Vthr = 15;
tauh = 0.04;
lambns = 55;
taunode = 0.033./rho;
n = 1e0; % node length in \mu m
L = 2e-2*r; % length of myelin segment in cm;
lambn = lambns*1e-4*sqrt(r); % cable constant at node in cm
lambn2 = lambns*sqrt(r); % cable constant at node in \mu m
I0 = I0s*1e-12;

% exponential current:
ft2Ltlanode = @(s,L,tau2,lamb) fCabExp(s,L,lamb,taunode,tau2);

% sodium current:
maxNa = ((3*tauh/taum)/((3*tauh/taum)+1))^3*(1/(3*tauh/taum+1))^(taum/tauh);
ftNala0m1 = @(s,L,lamb) (1/maxNa).*( ft2Ltlanode(s,L,tauh,lamb) - ft2Ltlanode(s,L,1/(1/taum+1/tauh),lamb) );
ftotNaFHNm1 = @(s,L,N) rho.*0.5.*1e4*L*I0*3.3*1e12.*( ...
            sum(ftNala0m1(s(:)*[1:N],repmat(L,[numel(s) 1])*[1:N],lambn./sqrt(rho)),2) );

% compute velocity:
v_un = 1e-3/flogsolve(@(t) ftotNaFHNm1(t,1e-4,1e3)-Vthr); 
crm1 = v_un;

end

% END OF FILE