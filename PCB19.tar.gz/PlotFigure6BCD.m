% Plot Figure 6, Panels B-D.

close all; clear all;

% parameters:
g = 0.81;
tau = 1.45; % cable time constant ms
taunode = 0.02;
r = 0.365; % axon radius in \mu m
n = 1e0; % node length in \mu m
L = 2e-2*r; % length of myelin segment in cm;
NL = 10; % number of myelin segments;
lamb = 24e-2*r*sqrt(-log(g)); % cable constant
lambn = 68e-4*sqrt(r); % cable constant at node in cm
lambn2 = 68*sqrt(r); % cable constant at node in \mu m
d = 2e-4;
RmRn = 394*log(1/g); % Rm / Rn in \mu m^{-1}
I0 = 200e-12;
Icab = I0*2*pi*r*n/(1+pi*r*n*RmRn/(10^4*lamb));
Rlamb = 130e9*log(1/g)/lamb; % factor 1e3 because of [mV]
taum = 0.07;
tauh = 0.16;
taun = 0.15;
tauk = 2.*taun;
Vth = 4;

% response to exponential currents (myelinated + unmyelinated):
ft2Ltla = @(s,L,tau2,lamb) fCabExp(s,L,lamb,tau,tau2);
ft2Ltlan = @(s,L,tau2,lamb) fCabExp(s,L,lamb,taunode,tau2);

% sodium current:
maxNa = ((3*tauh/taum)/((3*tauh/taum)+1))^3*(1/(3*tauh/taum+1))^(taum/tauh);
maxNam1 = ((1*tauh/taum)/((1*tauh/taum)+1))^1*(1/(1*tauh/taum+1))^(taum/tauh);

% response to epxonential currents (unmyelinated + myelinated):
ftNala0m1 = @(s,L,lamb) (1/maxNa).*( ft2Ltlan(s,L,tauh,lamb) - ft2Ltlan(s,L,1/(1/taum+1/tauh),lamb) );
ftNalam1 = @(s,L,lamb) Rlamb*Icab*(1/maxNam1).*( ft2Ltla(s,L,tauh,lamb) - 1.*ft2Ltla(s,L,1/(1/taum+1/tauh),lamb) );

% sum over currents:        
ftotNam1N2 = @(s,L,l,N) ((I0/Icab)*2*pi*r*l/(1+pi*r*l*RmRn/(10^4*lamb))).*( ...
            sum(ftNalam1(s(:)*[1:N],repmat(L+l*lamb/lambn2,[numel(s) 1])*[1:N],lamb).*exp(-0.*repmat(l,[numel(s) 1])*[1:N]./lambn2),2) );
        
% mimicking unmyelinated axon:  
ftotNaFHNm1 = @(s,L,N) 0.5.*I0*3.3*1e12.*( ...
            sum(ftNala0m1(s(:)*[1:N],repmat(L,[numel(s) 1])*[1:N],lambn),2) );

% Figure 6B:
N1 = 72;
N2 = 64;
Vthr = 4;
v_un_1 = 1e-3/flogsolve(@(t) ftotNaFHNm1(t,1e-4,1e3)-Vthr); 
Nnb = 1e3;
L = 0.01;
for p = 1:N1
    for m = 1:N2
        if p>1
            tinFH = ttFHold(m);
        else
            tinFH = 0.005;
        end
        ttm1 = fsolve(@(t) ftotNam1N2(t,L*(0.1+(1.8/N1)*(p-1)),m*(4/N2),Nnb)-Vthr,tinFH,...
            optimoptions('fsolve','Display','off','FunctionTolerance',1e-8,'StepTolerance',1e-8)); 
        crm1(m,p) = (10*L*(0.1+(1.8/N1)*(p-1))+m*(4/N2)*1e-3)/ttm1; 
        crm1_corr(m,p) = (1e4*L*(0.1+(1.8/N1)*(p-1))+m*(4/N2))*crm1(m,p)*v_un_1/...
            (m*(4/N2)*crm1(m,p) + 1e4*L*(0.1+(1.8/N1)*(p-1))*v_un_1);
        ttFHold(m) = ttm1;
    end
    disp([p N1]); 
end

figure; imagesc(crm1_corr'); axis xy

% compare with biophysical model:
Lx = 1e4*L.*(0.1+(1.8/N1).*[1:N1]);
nx = (4/N2).*[1:N2];

Lx2 = [27 55 82 106 130 154 180];
nx2 = 0.5.*[1:8];

vac1 = [2.56 2.66 2.61 2.51 2.42 2.32 2.23 2.14;
        2.20 2.53 2.61 2.61 2.57 2.51 2.44 2.37;
        1.75 2.15 2.27 2.31 2.29 2.26 2.22 2.16];
    
vac2 = [2.56 2.39 2.20 2.04 1.89 1.75 1.61;
        2.61 2.70 2.61 2.50 2.39 2.27 2.16;
        2.23 2.45 2.44 2.38 2.30 2.22 2.12];

% Figure 6C:
figure; plot(nx,0.2.*crm1_corr(:,6)+0.8.*crm1_corr(:,7)); hold on;
plot(nx,0.2.*crm1_corr(:,28)+0.8.*crm1_corr(:,29));
plot(nx,0.4.*crm1_corr(:,57)+0.6.*crm1_corr(:,58));
plot(nx2,vac1(1,:),'.','MarkerSize',14);
plot(nx2,vac1(2,:),'.','MarkerSize',14);
plot(nx2,vac1(3,:),'.','MarkerSize',14);

% Figure 6D:
figure; plot(Lx,crm1_corr(8,:)); hold on;
plot(Lx,crm1_corr(24,:));
plot(Lx,crm1_corr(56,:));
plot(Lx2,vac2(1,:),'.','MarkerSize',14);
plot(Lx2,vac2(2,:),'.','MarkerSize',14);
plot(Lx2,vac2(3,:),'.','MarkerSize',14);


% END OF FILE